const apiKey = "Enter the openweathermap secret key here";
